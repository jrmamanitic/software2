import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AppProvider } from '@/contexts/AppContext';
import Layout from '@/components/Layout';
import HomePage from '@/pages/HomePage';
import CartPage from '@/pages/CartPage';
import PaymentSuccessPage from '@/pages/PaymentSuccessPage';
import AdminLoginPage from '@/pages/admin/AdminLoginPage';
import AdminDashboardPage from '@/pages/admin/AdminDashboardPage';
import AdminProductFormPage from '@/pages/admin/AdminProductFormPage';
import AdminProductsListPage from '@/pages/admin/AdminProductsListPage';
import ProtectedRoute from '@/components/ProtectedRoute';
import { Toaster } from '@/components/ui/toaster';

function App() {
  return (
    <AppProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<HomePage />} />
            <Route path="cart" element={<CartPage />} />
            <Route path="payment-success" element={<PaymentSuccessPage />} />
            
            <Route path="admin" element={<AdminLoginPage />} />
            <Route path="admin" element={<ProtectedRoute />}>
              <Route path="dashboard" element={<AdminDashboardPage />} />
              <Route path="products" element={<AdminProductsListPage />} />
              <Route path="products/new" element={<AdminProductFormPage />} />
              <Route path="products/edit/:productId" element={<AdminProductFormPage />} />
            </Route>
          </Route>
        </Routes>
      </Router>
      <Toaster/>
    </AppProvider>
  );
}

export default App;