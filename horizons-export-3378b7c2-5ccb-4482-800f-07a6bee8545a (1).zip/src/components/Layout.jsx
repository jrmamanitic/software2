import React from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { Coffee, ShoppingCart, UserCog, LogOut, Home as HomeIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Toaster } from '@/components/ui/toaster';
import { useAppContext } from '@/contexts/AppContext';
import { motion } from 'framer-motion';

const Layout = () => {
  const { cart, isAdminAuthenticated, logoutAdmin } = useAppContext();
  const location = useLocation();
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const isAdminPage = location.pathname.startsWith('/admin');
  const cafeName = "Buenísimo Café";

  return (
    <div className="min-h-screen flex flex-col bg-brand-light font-body text-brand-text">
      <motion.header 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ type: 'spring', stiffness: 50 }}
        className="bg-gradient-to-r from-brand-dark via-brand to-brand-accent text-white shadow-lg sticky top-0 z-50"
      >
        <nav className="container mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-20">
          <Link to="/" className="flex items-center space-x-2 group">
            <Coffee className="h-10 w-10 text-brand-light group-hover:animate-pulse transform group-hover:scale-110 transition-transform duration-300" />
            <h1 className="text-3xl font-heading font-bold tracking-tight text-brand-light group-hover:text-white transition-colors">{cafeName}</h1>
          </Link>
          <div className="flex items-center space-x-4">
            {!isAdminPage && (
              <>
                <Link to="/" className="hover:text-brand-light transition-colors font-medium flex items-center space-x-1">
                  <HomeIcon size={20} /> <span>Inicio</span>
                </Link>
                <Link to="/cart" className="relative hover:text-brand-light transition-colors font-medium flex items-center space-x-1">
                  <ShoppingCart size={20} /> <span>Carrito</span>
                  {cartItemCount > 0 && (
                    <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                      {cartItemCount}
                    </span>
                  )}
                </Link>
              </>
            )}
             {isAdminAuthenticated ? (
               <>
                <Link to="/admin/dashboard" className="hover:text-brand-light transition-colors font-medium flex items-center space-x-1">
                  <UserCog size={20} /> <span>Admin</span>
                </Link>
                <Button variant="ghost" size="sm" onClick={logoutAdmin} className="text-white hover:bg-brand-light hover:text-brand-dark flex items-center space-x-1">
                  <LogOut size={20} /> <span>Salir</span>
                </Button>
               </>
             ) : (
              !isAdminPage && <Link to="/admin" className="hover:text-brand-light transition-colors font-medium flex items-center space-x-1">
                <UserCog size={20} /> <span>Admin</span>
              </Link>
             )}
          </div>
        </nav>
      </motion.header>

      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Outlet />
      </main>

      <motion.footer 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.5 }}
        className="bg-brand-dark text-brand-light py-8 text-center"
      >
        <div className="container mx-auto">
          <p className="text-sm">&copy; {new Date().getFullYear()} {cafeName}. Todos los derechos reservados.</p>
          <p className="text-xs mt-1">Diseñado con <span role="img" aria-label="love">❤️</span> y mucho café.</p>
        </div>
      </motion.footer>
      <Toaster />
    </div>
  );
};

export default Layout;