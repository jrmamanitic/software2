import React from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/contexts/AppContext';
import { ShoppingCart } from 'lucide-react';
import { motion } from 'framer-motion';

const ProductCard = ({ product }) => {
  const { addToCart } = useAppContext();

  const getImageUrl = (imageNameOrUrl) => {
    if (!imageNameOrUrl) {
      return `https://source.unsplash.com/random/400x300/?coffee,food,${product.name.split(" ")[0] || 'cafe'}&sig=${product.id}`;
    }
    if (imageNameOrUrl.startsWith('http://') || imageNameOrUrl.startsWith('https://')) {
      return imageNameOrUrl;
    }
    return `https://source.unsplash.com/random/400x300/?${imageNameOrUrl.replace(/\s+/g, ',')},coffee,food&sig=${product.id}`;
  };
  
  const imageUrl = getImageUrl(product.image_url);

  return (
    <motion.div
      whileHover={{ y: -5, boxShadow: "0px 10px 20px rgba(0,0,0,0.1)" }}
      transition={{ type: "spring", stiffness: 300 }}
      className="h-full"
    >
      <Card className="flex flex-col h-full overflow-hidden border-brand-dark/20 hover:border-brand-dark transition-all duration-300 rounded-xl shadow-lg hover:shadow-2xl bg-white/80 backdrop-blur-sm">
        <CardHeader className="p-0">
          <div className="relative w-full h-56 overflow-hidden">
            <img   
              class="w-full h-full object-cover transition-transform duration-500 ease-in-out hover:scale-110" 
              alt={product.name}
              src={imageUrl} src="https://images.unsplash.com/photo-1559223669-e0065fa7f142" />
            <div className="absolute top-2 right-2 bg-brand-accent text-white text-xs font-semibold px-2 py-1 rounded-full shadow">
              {product.category}
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6 flex-grow">
          <CardTitle className="text-2xl font-heading mb-2 text-brand-dark">{product.name}</CardTitle>
          <CardDescription className="text-brand-text/80 text-sm mb-3 h-16 overflow-hidden">{product.description}</CardDescription>
          <p className="text-2xl font-semibold font-heading text-brand-accent">${product.price ? product.price.toFixed(2) : '0.00'}</p>
        </CardContent>
        <CardFooter className="p-6 pt-0">
          <Button 
            onClick={() => addToCart(product)} 
            className="w-full bg-brand hover:bg-brand-dark text-white font-semibold transition-all duration-300 transform hover:scale-105 flex items-center space-x-2"
            aria-label={`Añadir ${product.name} al carrito`}
          >
            <ShoppingCart size={18} />
            <span>Añadir al Carrito</span>
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default ProductCard;