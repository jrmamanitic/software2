
import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';

const ProtectedRoute = ({ children }) => {
  const { isAdminAuthenticated } = useAppContext();

  if (!isAdminAuthenticated) {
    return <Navigate to="/admin" replace />;
  }

  return children ? children : <Outlet />;
};

export default ProtectedRoute;
  