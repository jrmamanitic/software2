import React, { useEffect, useState } from 'react';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, Loader2, AlertTriangle, Home } from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';

const PaymentSuccessPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { clearCart, fetchOrders, isAdminAuthenticated } = useAppContext();
  const [status, setStatus] = useState('loading'); // loading, success, error
  const [orderDetails, setOrderDetails] = useState(null);

  useEffect(() => {
    const sessionId = searchParams.get('session_id');
    const orderId = searchParams.get('order_id');

    if (!sessionId || !orderId) {
      toast({ title: "Error", description: "Faltan parámetros de sesión o pedido.", variant: "destructive" });
      setStatus('error');
      navigate('/');
      return;
    }

    const updateOrderStatus = async () => {
      try {
        const { data: order, error: fetchError } = await supabase
          .from('orders')
          .select('*')
          .eq('id', orderId)
          .single();

        if (fetchError || !order) {
          throw new Error(fetchError?.message || "Pedido no encontrado.");
        }
        
        setOrderDetails(order);

        if (order.status === 'completed') {
          setStatus('success');
          clearCart(); 
          if (isAdminAuthenticated) fetchOrders();
          return;
        }
        
        const { error: updateError } = await supabase
          .from('orders')
          .update({ status: 'completed', stripe_session_id: sessionId })
          .eq('id', orderId);

        if (updateError) {
          throw new Error(updateError.message);
        }
        
        setStatus('success');
        clearCart(); 
        if (isAdminAuthenticated) fetchOrders();
        
        console.log(`Correo de confirmación (simulado): Pedido ${orderId} enviado a ${order.customer_email}. Gracias por la compra.`);
        toast({
          title: "¡Pago Exitoso!",
          description: `Tu pedido ${orderId.substring(0,8)}... ha sido confirmado. Recibirás un correo con los detalles.`,
          className: "bg-green-500 text-white",
          duration: 7000,
        });

      } catch (err) {
        toast({ title: "Error al actualizar pedido", description: err.message, variant: "destructive" });
        setStatus('error');
      }
    };

    updateOrderStatus();
  }, [searchParams, toast, clearCart, navigate, fetchOrders, isAdminAuthenticated]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center justify-center min-h-[calc(100vh-16rem)] p-4"
    >
      <Card className="w-full max-w-lg shadow-xl bg-white/95 backdrop-blur-md">
        <CardHeader className="text-center">
          {status === 'loading' && <Loader2 className="mx-auto h-16 w-16 text-brand animate-spin" />}
          {status === 'success' && <CheckCircle className="mx-auto h-16 w-16 text-green-500" />}
          {status === 'error' && <AlertTriangle className="mx-auto h-16 w-16 text-red-500" />}
          
          <CardTitle className="text-3xl font-heading mt-4">
            {status === 'loading' && 'Procesando tu pago...'}
            {status === 'success' && '¡Pago Exitoso!'}
            {status === 'error' && 'Error en el Pago'}
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          {status === 'loading' && (
            <p className="text-muted-foreground">Estamos confirmando tu pago. Por favor, espera un momento.</p>
          )}
          {status === 'success' && orderDetails && (
            <>
              <CardDescription className="text-lg">
                ¡Gracias por tu compra en Buenísimo Café!
              </CardDescription>
              <p className="text-muted-foreground">
                Tu pedido con ID <span className="font-semibold text-brand-dark">{orderDetails.id.substring(0,8)}...</span> ha sido procesado correctamente.
              </p>
              <p className="text-sm text-muted-foreground">
                Se ha enviado una confirmación (simulada) a <span className="font-semibold text-brand-dark">{orderDetails.customer_email}</span>.
              </p>
            </>
          )}
          {status === 'error' && (
            <>
              <CardDescription className="text-lg text-red-600">
                Hubo un problema al procesar tu pago.
              </CardDescription>
              <p className="text-muted-foreground">
                Por favor, intenta de nuevo o contacta a soporte si el problema persiste.
              </p>
            </>
          )}
          <div className="pt-4">
            <Link to="/">
              <Button className="bg-brand hover:bg-brand-dark text-white font-semibold w-full sm:w-auto">
                <Home size={18} className="mr-2"/> Volver al Inicio
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default PaymentSuccessPage;