import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { LogIn, Coffee } from 'lucide-react';
import { motion } from 'framer-motion';

const AdminLoginPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const { loginAdmin } = useAppContext();
  const navigate = useNavigate();
  const cafeName = "Buenísimo Café";

  const handleSubmit = (e) => {
    e.preventDefault();
    if (loginAdmin(username, password)) {
      navigate('/admin/dashboard');
    }
  };

  return (
    <div className="min-h-[calc(100vh-10rem)] flex items-center justify-center bg-gradient-to-br from-brand-light via-brand-accent/10 to-brand-light p-4">
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="w-full max-w-md shadow-2xl bg-white/90 backdrop-blur-md border-brand-dark/20 rounded-xl">
          <CardHeader className="text-center space-y-2 pt-8">
            <Coffee className="mx-auto h-16 w-16 text-brand animate-bounce" />
            <CardTitle className="text-3xl font-heading text-brand-dark">Admin Login</CardTitle>
            <CardDescription className="text-brand-text/80">Accede al panel de administración de {cafeName}.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="username_admin" className="text-brand-dark font-semibold">Usuario</Label>
                <Input
                  id="username_admin"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="admin"
                  className="bg-white/70 border-brand-dark/30 focus:border-brand focus:ring-brand"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password_admin" className="text-brand-dark font-semibold">Contraseña</Label>
                <Input
                  id="password_admin"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="bg-white/70 border-brand-dark/30 focus:border-brand focus:ring-brand"
                  required
                />
              </div>
              <Button type="submit" className="w-full bg-brand hover:bg-brand-dark text-white font-bold py-3 text-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2">
                <LogIn size={20} />
                <span>Ingresar</span>
              </Button>
            </form>
          </CardContent>
          <CardFooter className="text-center pb-8">
            <p className="text-xs text-brand-text/70 w-full">Usa 'admin' y 'password123' para demostración.</p>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
};

export default AdminLoginPage;