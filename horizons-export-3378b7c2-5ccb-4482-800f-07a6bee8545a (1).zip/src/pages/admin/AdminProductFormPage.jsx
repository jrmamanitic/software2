import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea'; 
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { PlusCircle, Edit3, PackagePlus, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from "@/components/ui/use-toast"

const AdminProductFormPage = () => {
  const { addProduct, products, updateProduct } = useAppContext(); 
  const navigate = useNavigate();
  const { productId } = useParams();
  const { toast } = useToast();
  
  const isEditing = Boolean(productId);
  const [isLoading, setIsLoading] = useState(false);

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('');
  const [stock, setStock] = useState('');
  const [imageUrl, setImageUrl] = useState('');

  useEffect(() => {
    if (isEditing && products.length > 0) {
      const productToEdit = products.find(p => p.id === productId);
      if (productToEdit) {
        setName(productToEdit.name);
        setDescription(productToEdit.description);
        setPrice(productToEdit.price.toString());
        setCategory(productToEdit.category);
        setStock(productToEdit.stock.toString());
        setImageUrl(productToEdit.image_url || ''); 
      } else {
         toast({ title: "Error", description: "Producto no encontrado.", variant: "destructive" });
         navigate('/admin/products');
      }
    } else if (isEditing && products.length === 0) {
      // Products might still be loading, or product genuinely not found
      // This case might need a dedicated loading state or a re-fetch for the specific product
    }
  }, [productId, products, isEditing, navigate, toast]);


  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name || !description || !price || !category || !stock) {
      toast({ title: "Error", description: "Por favor, completa todos los campos.", variant: "destructive" });
      return;
    }
    setIsLoading(true);
    const productData = { 
      name, 
      description, 
      price: parseFloat(price), 
      category, 
      stock: parseInt(stock),
      image_url: imageUrl || name.toLowerCase().replace(/\s+/g, '-') 
    };

    let success = false;
    if (isEditing) {
      const result = await updateProduct(productId, productData);
      if (result) success = true;
    } else {
      const result = await addProduct(productData);
      if (result) success = true;
    }
    
    setIsLoading(false);
    if (success) {
      navigate('/admin/products');
    }
  };
  
  const TextareaComponent = Textarea || (({className, ...props}) => <textarea className={`flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 ${className}`} {...props} />);


  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="max-w-2xl mx-auto p-4 sm:p-6 md:p-8"
    >
      <Card className="shadow-xl bg-white/90 backdrop-blur-md border-brand-dark/10 rounded-xl">
        <CardHeader className="text-center">
          {isEditing ? <Edit3 className="mx-auto h-12 w-12 text-brand-accent" /> : <PackagePlus className="mx-auto h-12 w-12 text-brand" />}
          <CardTitle className="text-3xl font-heading text-brand-dark">{isEditing ? 'Editar Producto' : 'Añadir Nuevo Producto'}</CardTitle>
          <CardDescription className="text-brand-text/80">{isEditing ? 'Modifica los detalles del producto.' : 'Completa el formulario para añadir un nuevo ítem al menú.'}</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="name" className="text-brand-dark font-semibold">Nombre del Producto</Label>
              <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required className="bg-white/70 border-brand-dark/30 focus:border-brand focus:ring-brand" disabled={isLoading} />
            </div>
            <div>
              <Label htmlFor="description" className="text-brand-dark font-semibold">Descripción</Label>
              <TextareaComponent id="description" value={description} onChange={(e) => setDescription(e.target.value)} required className="bg-white/70 border-brand-dark/30 focus:border-brand focus:ring-brand" disabled={isLoading} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="price" className="text-brand-dark font-semibold">Precio ($)</Label>
                <Input id="price" type="number" step="0.01" value={price} onChange={(e) => setPrice(e.target.value)} required className="bg-white/70 border-brand-dark/30 focus:border-brand focus:ring-brand" disabled={isLoading} />
              </div>
              <div>
                <Label htmlFor="category" className="text-brand-dark font-semibold">Categoría</Label>
                <Input id="category" value={category} onChange={(e) => setCategory(e.target.value)} required placeholder="Ej: Café, Postres, Bebidas" className="bg-white/70 border-brand-dark/30 focus:border-brand focus:ring-brand" disabled={isLoading} />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="stock" className="text-brand-dark font-semibold">Stock Disponible</Label>
                <Input id="stock" type="number" value={stock} onChange={(e) => setStock(e.target.value)} required className="bg-white/70 border-brand-dark/30 focus:border-brand focus:ring-brand" disabled={isLoading} />
              </div>
               <div>
                <Label htmlFor="imageUrl" className="text-brand-dark font-semibold">Nombre de Imagen (ej: 'espresso-premium')</Label>
                <Input id="imageUrl" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} placeholder="Se usará para <img-replace>" className="bg-white/70 border-brand-dark/30 focus:border-brand focus:ring-brand" disabled={isLoading} />
              </div>
            </div>
            <Button type="submit" className="w-full bg-brand hover:bg-brand-dark text-white font-bold py-3 text-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2" disabled={isLoading}>
              {isLoading ? (
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              ) : isEditing ? (
                <Edit3 size={20} />
              ) : (
                <PlusCircle size={20} />
              )}
              <span>{isLoading ? 'Guardando...' : isEditing ? 'Guardar Cambios' : 'Añadir Producto'}</span>
            </Button>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default AdminProductFormPage;