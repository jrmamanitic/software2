import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Edit3, Trash2, PlusCircle, PackageSearch, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useToast } from "@/components/ui/use-toast"

const AdminProductsListPage = () => {
  const { products, deleteProduct, loadingProducts } = useAppContext();
  const { toast } = useToast();
  const [deletingId, setDeletingId] = useState(null);

  const handleDeleteProduct = async (productId, productName) => {
    if (window.confirm(`¿Estás seguro de que quieres eliminar "${productName}"? Esta acción no se puede deshacer.`)) {
      setDeletingId(productId);
      const success = await deleteProduct(productId);
      if (success) {
        toast({
          title: "Producto Eliminado",
          description: `"${productName}" ha sido eliminado del menú.`,
        });
      } else {
         toast({
          title: "Error al Eliminar",
          description: `No se pudo eliminar "${productName}". Intenta de nuevo.`,
          variant: "destructive"
        });
      }
      setDeletingId(null);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
    },
  };

  if (loadingProducts) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-12 w-12 animate-spin text-brand" />
        <p className="ml-4 text-lg text-brand-dark">Cargando productos...</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="max-w-4xl mx-auto p-4 sm:p-6 md:p-8"
    >
      <Card className="shadow-xl bg-white/90 backdrop-blur-md border-brand-dark/10 rounded-xl">
        <CardHeader className="flex flex-col sm:flex-row items-center justify-between space-y-3 sm:space-y-0">
          <div className="text-center sm:text-left">
            <CardTitle className="text-3xl font-heading text-brand-dark flex items-center">
              <PackageSearch className="h-8 w-8 mr-3 text-brand" />
              Gestionar Productos
            </CardTitle>
            <CardDescription className="text-brand-text/80">
              Visualiza, edita o elimina productos del menú.
            </CardDescription>
          </div>
          <Link to="/admin/products/new">
            <Button className="bg-brand hover:bg-brand-dark text-white font-semibold transition-all duration-300 transform hover:scale-105 flex items-center space-x-2">
              <PlusCircle size={20} />
              <span>Añadir Nuevo Producto</span>
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {products && products.length > 0 ? (
            <div className="overflow-x-auto rounded-lg border border-brand-light">
              <Table>
                <TableHeader className="bg-brand-light/30">
                  <TableRow>
                    <TableHead className="font-semibold text-brand-dark">Nombre</TableHead>
                    <TableHead className="font-semibold text-brand-dark">Categoría</TableHead>
                    <TableHead className="text-right font-semibold text-brand-dark">Precio</TableHead>
                    <TableHead className="text-right font-semibold text-brand-dark">Stock</TableHead>
                    <TableHead className="text-center font-semibold text-brand-dark">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody
                  as={motion.tbody}
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                >
                  {products.map((product) => (
                    <motion.tr key={product.id} variants={itemVariants} className="hover:bg-brand-light/20 transition-colors">
                      <TableCell className="font-medium text-brand-text">{product.name}</TableCell>
                      <TableCell className="text-brand-text/90">{product.category}</TableCell>
                      <TableCell className="text-right text-brand-text/90">${product.price ? product.price.toFixed(2) : '0.00'}</TableCell>
                      <TableCell className="text-right text-brand-text/90">{product.stock}</TableCell>
                      <TableCell className="text-center space-x-2">
                        <Link to={`/admin/products/edit/${product.id}`}>
                          <Button variant="ghost" size="icon" className="text-blue-600 hover:bg-blue-100 hover:text-blue-700" disabled={deletingId === product.id}>
                            <Edit3 size={18} />
                          </Button>
                        </Link>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-red-600 hover:bg-red-100 hover:text-red-700"
                          onClick={() => handleDeleteProduct(product.id, product.name)}
                          disabled={deletingId === product.id}
                        >
                          {deletingId === product.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 size={18} />}
                        </Button>
                      </TableCell>
                    </motion.tr>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              <PackageSearch size={48} className="mx-auto text-gray-400 mb-3" />
              <p className="text-lg text-gray-600">No hay productos en el menú.</p>
              <p className="text-sm text-gray-500">Empieza añadiendo algunos.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default AdminProductsListPage;