import React, { useEffect, useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BarChart, DollarSign, ShoppingBag, PlusCircle, ListOrdered, CalendarDays, Loader2, Filter } from 'lucide-react';
import { motion } from 'framer-motion';
import { format, parseISO, startOfDay, endOfDay, subDays, isWithinInterval, isValid } from 'date-fns';
import { es } from 'date-fns/locale';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title as ChartTitle,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ChartTitle,
  Tooltip,
  Legend
);

const StatCard = ({ title, value, icon, color, bgColor }) => {
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };
  return (
    <motion.div variants={cardVariants}>
      <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 rounded-xl border-brand-dark/10 overflow-hidden">
        <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${bgColor} p-6`}>
          <CardTitle className={`text-sm font-medium ${color}`}>{title}</CardTitle>
          {React.cloneElement(icon, {className: `h-6 w-6 ${color}`})}
        </CardHeader>
        <CardContent className="p-6 bg-white">
          <div className={`text-3xl font-bold ${color}`}>{value}</div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

const SalesChart = ({ salesData }) => {
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { position: 'top', labels: { font: { family: 'Montserrat' }}},
      title: { display: true, text: `Ventas Diarias`, font: { size: 16, family: 'Playfair Display' }},
      tooltip: {
        callbacks: {
          label: function(context) {
            let label = context.dataset.label || '';
            if (label) label += ': ';
            if (context.parsed.y !== null) label += new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'USD' }).format(context.parsed.y);
            return label;
          }
        }
      }
    },
    scales: {
      y: { beginAtZero: true, ticks: { callback: value => '$' + value, font: { family: 'Montserrat' }}, grid: { color: 'rgba(0,0,0,0.05)'}},
      x: { ticks: { font: { family: 'Montserrat' }}, grid: { display: false }}
    }
  };
  return <Bar options={chartOptions} data={salesData} />;
};

const OrdersTable = ({ orders }) => (
  <div className="overflow-x-auto">
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>ID Pedido</TableHead>
          <TableHead>Cliente (Email)</TableHead>
          <TableHead>Fecha</TableHead>
          <TableHead>Dirección</TableHead>
          <TableHead className="text-right">Total</TableHead>
          <TableHead className="text-center">Items</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {orders.slice(0, 10).map(order => (
          <TableRow key={order.id}>
            <TableCell className="font-medium text-brand-accent hover:underline">
              <Link to={`#`} title={order.id}>{order.id.substring(0,8)}...</Link>
            </TableCell>
            <TableCell>{order.customer_email}</TableCell>
            <TableCell>{format(parseISO(order.created_at), 'Pp', { locale: es })}</TableCell>
            <TableCell>{order.shipping_address || 'N/A'}</TableCell>
            <TableCell className="text-right">${order.total_amount.toFixed(2)}</TableCell>
            <TableCell className="text-center">{order.order_items?.reduce((acc, item) => acc + item.quantity, 0) || 0}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  </div>
);


const AdminDashboardPage = () => {
  const { orders, loadingOrders, fetchOrders, products } = useAppContext();
  const [dateRange, setDateRange] = useState('today'); 

  useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);

  const filteredOrders = useMemo(() => {
    if (!orders) return [];
    let startDate, endDate = endOfDay(new Date());
    if (dateRange === 'today') {
      startDate = startOfDay(new Date());
    } else if (dateRange === 'last7days') {
      startDate = startOfDay(subDays(new Date(), 6));
    } else if (dateRange === 'last30days') {
      startDate = startOfDay(subDays(new Date(), 29));
    } else { // Default to today if range is unknown
      startDate = startOfDay(new Date());
    }

    return orders.filter(order => {
      const orderDate = parseISO(order.created_at);
      return isValid(orderDate) && isWithinInterval(orderDate, { start: startDate, end: endDate }) && order.status === 'completed';
    });
  }, [orders, dateRange]);

  const salesChartData = useMemo(() => {
    const dailySales = {};
    filteredOrders.forEach(order => {
      const day = format(parseISO(order.created_at), 'yyyy-MM-dd');
      dailySales[day] = (dailySales[day] || 0) + order.total_amount;
    });
    const sortedDays = Object.keys(dailySales).sort();
    const labels = sortedDays.map(day => format(parseISO(day), 'MMM d', { locale: es }));
    const data = sortedDays.map(day => dailySales[day]);
    return {
      labels,
      datasets: [{
        label: 'Ventas ($)', data, backgroundColor: 'rgba(142, 112, 87, 0.6)',
        borderColor: 'rgba(142, 112, 87, 1)', borderWidth: 1, borderRadius: 4,
        hoverBackgroundColor: 'rgba(142, 112, 87, 0.8)',
      }],
    };
  }, [filteredOrders]);

  const totalSales = filteredOrders.reduce((sum, order) => sum + order.total_amount, 0);
  const totalOrdersCount = filteredOrders.length;
  const activeProductsCount = products.length;

  const stats = [
    { title: `Ventas (${dateRange === 'today' ? 'Hoy' : 'Rango'})`, value: `$${totalSales.toFixed(2)}`, icon: <DollarSign />, color: "text-green-500", bgColor: "bg-green-100" },
    { title: `Pedidos (${dateRange === 'today' ? 'Hoy' : 'Rango'})`, value: totalOrdersCount, icon: <ShoppingBag />, color: "text-blue-500", bgColor: "bg-blue-100" },
    { title: 'Productos Activos', value: activeProductsCount, icon: <ListOrdered />, color: "text-purple-500", bgColor: "bg-purple-100" },
  ];
  
  const cardMotionProps = { initial:"hidden", animate:"visible", variants:{ visible: { transition: { staggerChildren: 0.1 }}}};
  const sectionMotionProps = (delay = 0) => ({ initial:{opacity:0, y:20}, animate:{opacity:1, y:0}, transition:{delay, duration:0.5}});

  return (
    <motion.div {...sectionMotionProps()} className="space-y-8 p-4 sm:p-6 md:p-8">
      <motion.div {...sectionMotionProps(0.1)} className="flex flex-col sm:flex-row justify-between items-center mb-10">
        <h1 className="text-4xl font-heading font-bold text-brand-dark mb-4 sm:mb-0">Panel de Administración</h1>
        <Link to="/admin/products/new">
          <Button className="bg-brand hover:bg-brand-dark text-white font-semibold transition-all duration-300 transform hover:scale-105 flex items-center space-x-2">
            <PlusCircle size={20} /><span>Añadir Producto</span>
          </Button>
        </Link>
      </motion.div>

      <div className="flex justify-end space-x-2 mb-6">
        {['today', 'last7days', 'last30days'].map(range => (
          <Button key={range} variant={dateRange === range ? 'default' : 'outline'} onClick={() => setDateRange(range)} className="flex items-center space-x-1">
            {range === 'today' ? <CalendarDays size={16}/> : <Filter size={16}/>}
            <span>{range === 'today' ? 'Hoy' : range === 'last7days' ? 'Últimos 7 Días' : 'Últimos 30 Días'}</span>
          </Button>
        ))}
      </div>

      {loadingOrders ? (
        <div className="flex justify-center items-center h-40"><Loader2 className="h-12 w-12 animate-spin text-brand" /> <p className="ml-3 text-brand-dark">Cargando datos...</p></div>
      ) : (
        <>
          <motion.div {...cardMotionProps} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {stats.map((stat, index) => <StatCard key={index} {...stat} />)}
          </motion.div>

          <motion.div {...sectionMotionProps(0.3)}>
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 rounded-xl border-brand-dark/10 overflow-hidden">
              <CardHeader className="bg-brand-light/50 p-6">
                <CardTitle className="text-xl font-heading text-brand-dark flex items-center"><BarChart className="h-6 w-6 mr-2 text-brand" />Resumen de Ventas</CardTitle>
              </CardHeader>
              <CardContent className="p-6 bg-white">
                {filteredOrders.length > 0 && salesChartData.labels.length > 0 ? (
                  <div className="h-80 md:h-96"><SalesChart salesData={salesChartData} /></div>
                ) : <p className="text-muted-foreground text-center py-10">No hay datos de ventas para el período seleccionado.</p>}
              </CardContent>
            </Card>
          </motion.div>

          <motion.div {...sectionMotionProps(0.4)}>
            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 rounded-xl border-brand-dark/10 overflow-hidden">
              <CardHeader className="bg-brand-light/50 p-6">
                <CardTitle className="text-xl font-heading text-brand-dark">Ventas del Día</CardTitle>
                <CardDescription>Mostrando todas las ventas completadas de hoy.</CardDescription>
              </CardHeader>
              <CardContent className="p-0 bg-white">
                {filteredOrders.length > 0 && dateRange === 'today' ? (
                  <OrdersTable orders={filteredOrders} />
                ) : dateRange === 'today' ? (
                  <p className="text-muted-foreground text-center p-10">No hay ventas completadas hoy.</p>
                ) : (
                  <p className="text-muted-foreground text-center p-10">Selecciona el filtro "Hoy" para ver las ventas del día.</p>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </>
      )}
      
      <motion.div {...sectionMotionProps(0.5)}>
         <Link to="/admin/products">
          <Button variant="outline" className="w-full border-brand text-brand hover:bg-brand hover:text-white transition-colors py-3 text-md">Gestionar Productos Existentes</Button>
        </Link>
      </motion.div>
    </motion.div>
  );
};

export default AdminDashboardPage;