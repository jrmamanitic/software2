import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import ProductCard from '@/components/ProductCard';
import { motion } from 'framer-motion';
import { Coffee, Loader2 } from 'lucide-react';

const HomePage = () => {
  const { products, loadingProducts } = useAppContext();
  const cafeName = "Buenísimo Café";

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      },
    },
  };
  
  const heroStyle = {
    '--hero-bg-url': `url('https://source.unsplash.com/random/1600x900/?coffee,cafe,modern,bright')`
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="space-y-12"
    >
      <motion.section 
        style={heroStyle}
        className="hero-bg text-white py-20 sm:py-32 rounded-xl shadow-2xl overflow-hidden"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.7, ease: "easeOut" }}
      >
        <div className="container mx-auto text-center px-4">
          <motion.h1 
            className="text-5xl sm:text-6xl md:text-7xl font-heading font-bold mb-6 drop-shadow-lg"
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5, type: 'spring', stiffness:120 }}
          >
            Bienvenido a <span className="text-brand-light italic">{cafeName}</span>
          </motion.h1>
          <motion.p 
            className="text-lg sm:text-xl md:text-2xl mb-8 max-w-2xl mx-auto font-body drop-shadow-md"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.5, type: 'spring', stiffness:120 }}
          >
            Donde cada taza cuenta una historia y cada bocado es una obra de arte.
          </motion.p>
          <motion.div
            initial={{ scale:0.5, opacity: 0 }}
            animate={{ scale:1, opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.5, type: 'spring', stiffness:120 }}
          >
            <a 
              href="#menu"
              className="bg-brand hover:bg-brand-dark text-white font-bold py-3 px-8 rounded-lg text-lg shadow-md transition-all duration-300 ease-in-out transform hover:scale-105 inline-flex items-center space-x-2"
            >
              <Coffee size={22}/>
              <span>Ver Menú</span>
            </a>
          </motion.div>
        </div>
      </motion.section>

      <section id="menu" className="py-8">
        <h2 className="text-4xl font-heading font-bold text-center mb-12 text-brand-dark">Nuestro Menú</h2>
        {loadingProducts ? (
          <div className="flex justify-center items-center h-40">
            <Loader2 className="h-12 w-12 animate-spin text-brand" />
            <p className="ml-4 text-lg text-brand-dark">Cargando menú...</p>
          </div>
        ) : products.length > 0 ? (
          <motion.div 
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {products.map((product) => (
              <motion.div key={product.id} variants={itemVariants}>
                <ProductCard product={product} />
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <p className="text-center text-gray-500">No hay productos disponibles en este momento.</p>
        )}
      </section>

      <section className="py-16 bg-brand-accent/10 rounded-xl">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-heading font-bold text-brand-dark mb-6">Visítanos</h2>
          <p className="text-lg text-brand-text mb-4 max-w-xl mx-auto">
            Disfruta de un ambiente acogedor, perfecto para relajarte, trabajar o compartir con amigos.
          </p>
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <img  
                class="rounded-lg shadow-lg w-full h-64 object-cover"
                alt="Interior de la cafetería Buenísimo Café"
                src="https://images.unsplash.com/photo-1559925393-8be0ec4767c8" />
            </div>
            <div className="text-left space-y-3">
              <p className="text-brand-text"><strong className="text-brand-dark">Dirección:</strong> Calle Ficticia 123, Ciudad Ejemplo</p>
              <p className="text-brand-text"><strong className="text-brand-dark">Horario:</strong> Lunes a Viernes: 8 AM - 8 PM | Sábados y Domingos: 9 AM - 6 PM</p>
              <p className="text-brand-text"><strong className="text-brand-dark">Teléfono:</strong> (123) 456-7890</p>
            </div>
          </div>
        </div>
      </section>
    </motion.div>
  );
};

export default HomePage;