import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Trash2, ShoppingBag, CreditCard, ArrowLeft, Loader2, MapPin } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from "@/components/ui/use-toast";
import { loadStripe } from '@stripe/stripe-js';
import { supabase } from '@/lib/supabaseClient';

const CartItem = ({ item, onUpdateQuantity, onRemoveItem }) => {
  const getImageUrl = (imageNameOrUrl, itemName) => {
    if (!imageNameOrUrl) {
      return `https://source.unsplash.com/random/100x100/?${itemName.split(" ")[0] || 'coffee'}&sig=${item.id}`;
    }
    if (imageNameOrUrl.startsWith('http://') || imageNameOrUrl.startsWith('https://')) {
      return imageNameOrUrl;
    }
    return `https://source.unsplash.com/random/100x100/?${imageNameOrUrl.replace(/\s+/g, ',')},coffee&sig=${item.id}`;
  };
  const imageUrl = getImageUrl(item.image_url, item.name);

  const itemVariants = {
    hidden: { opacity: 0, x: -50 },
    visible: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: 50, transition: { duration: 0.3 } }
  };

  return (
    <motion.div
      layout
      variants={itemVariants}
      initial="hidden"
      animate="visible"
      exit="exit"
      className="flex flex-col sm:flex-row items-center justify-between p-4 border border-brand-light rounded-lg shadow-sm bg-brand-light/30 hover:shadow-md transition-shadow"
    >
      <div className="flex items-center mb-4 sm:mb-0">
        <img 
          class="w-20 h-20 object-cover rounded-md mr-4"
          alt={item.name}
          src={imageUrl} src="https://images.unsplash.com/photo-1692986224021-eb0ec682ef73" />
        <div>
          <h2 className="text-lg font-semibold text-brand-dark">{item.name}</h2>
          <p className="text-sm text-brand-text/80">${item.price ? item.price.toFixed(2) : '0.00'} cada uno</p>
        </div>
      </div>
      <div className="flex items-center space-x-3 sm:space-x-4">
        <div className="flex items-center border border-brand-dark/30 rounded">
          <Button variant="ghost" size="sm" onClick={() => onUpdateQuantity(item.id, item.quantity - 1)} className="px-2 text-brand-dark hover:bg-brand-dark/10 rounded-r-none">-</Button>
          <Input
            type="number"
            min="1"
            value={item.quantity}
            onChange={(e) => onUpdateQuantity(item.id, parseInt(e.target.value))}
            className="w-12 h-8 text-center border-l-0 border-r-0 focus-visible:ring-0 rounded-none"
          />
          <Button variant="ghost" size="sm" onClick={() => onUpdateQuantity(item.id, item.quantity + 1)} className="px-2 text-brand-dark hover:bg-brand-dark/10 rounded-l-none">+</Button>
        </div>
        <p className="text-md font-semibold text-brand-accent w-20 text-right">${(item.price * item.quantity).toFixed(2)}</p>
        <Button variant="ghost" onClick={() => onRemoveItem(item.id)} className="text-red-500 hover:text-red-700 hover:bg-red-100 p-2">
          <Trash2 size={20} />
        </Button>
      </div>
    </motion.div>
  );
};

const CartPage = () => {
  const { cart, removeFromCart, updateQuantity, getCartTotal, clearCart, createOrder } = useAppContext();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const total = getCartTotal();

  const STRIPE_PUBLISHABLE_KEY = "YOUR_STRIPE_PUBLISHABLE_KEY"; 
  const STRIPE_PRICE_ID = "YOUR_STRIPE_PRICE_ID"; 

  let stripePromise;
  if (STRIPE_PUBLISHABLE_KEY !== "YOUR_STRIPE_PUBLISHABLE_KEY") {
    stripePromise = loadStripe(STRIPE_PUBLISHABLE_KEY);
  }

  const handleCheckout = async () => {
    if (cart.length === 0) {
      toast({ title: "Carrito Vacío", description: "Añade productos antes de pagar.", variant: "destructive" });
      return;
    }
    if (!email.trim() || !/^\S+@\S+\.\S+$/.test(email)) {
      toast({ title: "Correo Inválido", description: "Por favor, ingresa un correo electrónico válido.", variant: "destructive" });
      return;
    }
    if (!address.trim()) {
      toast({ title: "Dirección Requerida", description: "Por favor, ingresa tu dirección de envío.", variant: "destructive" });
      return;
    }

    setIsProcessing(true);

    const orderData = {
      total_amount: total,
      status: 'pending_payment', 
      customer_email: email,
      shipping_address: address, 
    };
    const itemsData = cart.map(item => ({
      product_id: item.id,
      quantity: item.quantity,
      price_at_purchase: item.price,
    }));

    if (STRIPE_PUBLISHABLE_KEY === "YOUR_STRIPE_PUBLISHABLE_KEY" || STRIPE_PRICE_ID === "YOUR_STRIPE_PRICE_ID") {
      toast({
        title: "Modo de Demostración",
        description: "Stripe no está configurado. Simulando creación de pedido.",
        variant: "default",
        duration: 5000,
      });
      
      const createdOrder = await createOrder(orderData, itemsData);
      if (createdOrder) {
        console.log("Pedido simulado creado:", createdOrder);
        console.log(`Correo de confirmación (simulado): Pedido enviado a ${email} en la dirección: ${address}`);
        toast({
          title: "¡Pedido Registrado (Simulado)!",
          description: "Gracias por tu compra. Tu pedido ha sido registrado.",
          className: "bg-green-500 text-white"
        });
        navigate('/');
      } else {
        toast({ title: "Error", description: "No se pudo registrar el pedido simulado.", variant: "destructive" });
      }
      setIsProcessing(false);
      return;
    }

    try {
      const stripe = await stripePromise;
      if (!stripe) {
        toast({ title: "Error de Stripe", description: "No se pudo cargar Stripe.", variant: "destructive" });
        setIsProcessing(false);
        return;
      }

      const preliminaryOrderData = { ...orderData, status: 'pending_stripe_session' };
      const preliminaryOrder = await createOrder(preliminaryOrderData, itemsData);

      if (!preliminaryOrder || !preliminaryOrder.id) {
        toast({ title: "Error de Pedido", description: "No se pudo pre-registrar el pedido.", variant: "destructive" });
        setIsProcessing(false);
        return;
      }
      
      const { error } = await stripe.redirectToCheckout({
        lineItems: [{ price: STRIPE_PRICE_ID, quantity: 1 }], 
        mode: 'payment',
        successUrl: `${window.location.origin}/payment-success?session_id={CHECKOUT_SESSION_ID}&order_id=${preliminaryOrder.id}`,
        cancelUrl: `${window.location.origin}/cart?payment_cancelled=true`,
        customerEmail: email,
      });

      if (error) {
        toast({ title: "Error de Stripe", description: error.message, variant: "destructive" });
        await supabase.from('orders').update({ status: 'failed_stripe_redirect' }).eq('id', preliminaryOrder.id);
      }
    } catch (err) {
      toast({ title: "Error Inesperado", description: err.message, variant: "destructive" });
    } finally {
      setIsProcessing(false); 
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y:20 }}
      animate={{ opacity: 1, y:0 }}
      exit={{ opacity: 0, y:20 }}
      className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 bg-white shadow-xl rounded-xl"
    >
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-4xl font-heading font-bold text-brand-dark">Tu Carrito</h1>
        <Link to="/" className="text-brand hover:text-brand-dark transition-colors flex items-center">
          <ArrowLeft size={18} className="mr-1" /> Continuar Comprando
        </Link>
      </div>

      {cart.length === 0 ? (
        <motion.div 
          initial={{ opacity:0, scale:0.8 }}
          animate={{ opacity:1, scale:1 }}
          className="text-center py-12"
        >
          <ShoppingBag size={64} className="mx-auto text-gray-400 mb-4" />
          <p className="text-xl text-gray-600 mb-2">Tu carrito está vacío.</p>
          <p className="text-gray-500">¡Añade algunos productos deliciosos!</p>
        </motion.div>
      ) : (
        <>
          <div className="space-y-6 mb-8">
            <AnimatePresence>
              {cart.map((item) => (
                <CartItem key={item.id} item={item} onUpdateQuantity={updateQuantity} onRemoveItem={removeFromCart} />
              ))}
            </AnimatePresence>
          </div>

          <div className="mt-8 p-6 bg-brand-light/50 rounded-lg shadow">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <Label htmlFor="email" className="text-brand-dark font-semibold">Correo Electrónico</Label>
                <Input 
                  id="email" 
                  type="email" 
                  value={email} 
                  onChange={(e) => setEmail(e.target.value)} 
                  placeholder="tu@correo.com" 
                  required 
                  className="mt-1 bg-white/70 border-brand-dark/30 focus:border-brand focus:ring-brand"
                />
              </div>
              <div>
                <Label htmlFor="address" className="text-brand-dark font-semibold">Dirección de Envío</Label>
                <Textarea
                  id="address"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Calle, Número, Ciudad, Código Postal"
                  required
                  className="mt-1 bg-white/70 border-brand-dark/30 focus:border-brand focus:ring-brand min-h-[40px]"
                />
              </div>
            </div>

            <div className="flex justify-between items-center mb-4">
              <p className="text-xl font-semibold text-brand-dark">Subtotal:</p>
              <p className="text-xl font-semibold text-brand-accent">${total.toFixed(2)}</p>
            </div>
            <div className="flex justify-between items-center mb-4">
              <p className="text-md text-brand-text">Envío:</p>
              <p className="text-md text-brand-text">Gratis</p>
            </div>
            <hr className="my-4 border-brand-dark/20" />
            <div className="flex justify-between items-center mb-6">
              <p className="text-2xl font-bold text-brand-dark">Total:</p>
              <p className="text-2xl font-bold text-brand-accent">${total.toFixed(2)}</p>
            </div>
            <Button 
              onClick={handleCheckout} 
              className="w-full bg-brand hover:bg-brand-dark text-white font-bold py-3 text-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2"
              disabled={cart.length === 0 || isProcessing || (STRIPE_PUBLISHABLE_KEY !== "YOUR_STRIPE_PUBLISHABLE_KEY" && !stripePromise)}
            >
              {isProcessing ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <CreditCard size={22} />}
              <span>{isProcessing ? 'Procesando...' : 'Pagar con Stripe'}</span>
            </Button>
            {STRIPE_PUBLISHABLE_KEY === "YOUR_STRIPE_PUBLISHABLE_KEY" && (
                 <p className="text-xs text-center mt-2 text-orange-600">Modo demostración: Stripe no configurado. Se simulará el pedido.</p>
            )}
            <Button 
              variant="outline" 
              onClick={() => { clearCart(); toast({ title: "Carrito Vaciado", description: "Tu carrito ahora está vacío." }); }}
              className="w-full mt-3 text-red-600 border-red-500 hover:bg-red-500 hover:text-white"
              disabled={cart.length === 0 || isProcessing}
            >
              Vaciar Carrito
            </Button>
          </div>
        </>
      )}
    </motion.div>
  );
};

export default CartPage;