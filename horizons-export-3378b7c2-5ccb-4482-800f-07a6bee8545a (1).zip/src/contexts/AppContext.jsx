import React, { createContext, useState, useEffect, useContext } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { 
  fetchProductsFromDB, 
  addProductToDB, 
  updateProductInDB, 
  deleteProductFromDB 
} from '@/services/productService';
import { 
  fetchOrdersFromDB, 
  createOrderInDB 
} from '@/services/orderService';
import { 
  getCartFromStorage, 
  saveCartToStorage 
} from '@/lib/cartStorage';
import { 
  getAdminAuthStatus, 
  setAdminAuthStatus 
} from '@/lib/adminAuth';

const AppContext = createContext();

export const useAppContext = () => useContext(AppContext);

export const AppProvider = ({ children }) => {
  const { toast } = useToast();
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState(getCartFromStorage());
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(getAdminAuthStatus());
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [orders, setOrders] = useState([]);
  const [loadingOrders, setLoadingOrders] = useState(false);

  useEffect(() => {
    const loadProducts = async () => {
      setLoadingProducts(true);
      const { data, error } = await fetchProductsFromDB();
      if (error) {
        toast({ title: "Error al cargar productos", description: error.message, variant: "destructive" });
        setProducts([]);
      } else {
        setProducts(data || []);
      }
      setLoadingProducts(false);
    };
    loadProducts();
  }, [toast]);

  const loadOrders = async () => {
    if (!isAdminAuthenticated) return;
    setLoadingOrders(true);
    const { data, error } = await fetchOrdersFromDB();
    if (error) {
      toast({ title: "Error al cargar pedidos", description: error.message, variant: "destructive" });
      setOrders([]);
    } else {
      setOrders(data || []);
    }
    setLoadingOrders(false);
  };
  
  useEffect(() => {
    if (isAdminAuthenticated) {
      loadOrders();
    }
  }, [isAdminAuthenticated, toast]);


  useEffect(() => {
    saveCartToStorage(cart);
  }, [cart]);

  useEffect(() => {
    setAdminAuthStatus(isAdminAuthenticated);
  }, [isAdminAuthenticated]);

  const addProduct = async (productData) => {
    const { data, error } = await addProductToDB(productData);
    if (error) {
      toast({ title: "Error al añadir producto", description: error.message, variant: "destructive" });
      return null;
    }
    if (data) {
      setProducts((prevProducts) => [data, ...prevProducts]);
      toast({ title: "Producto Añadido", description: `${data.name} ha sido añadido al menú.` });
      return data;
    }
    return null;
  };
  
  const updateProduct = async (productId, productData) => {
    const { data, error } = await updateProductInDB(productId, productData);
    if (error) {
      toast({ title: "Error al actualizar producto", description: error.message, variant: "destructive" });
      return null;
    }
    if (data) {
      setProducts((prevProducts) => 
        prevProducts.map(p => p.id === productId ? data : p)
      );
      toast({ title: "Producto Actualizado", description: `${data.name} ha sido actualizado.` });
      return data;
    }
    return null;
  };

  const deleteProduct = async (productId) => {
    const success = await deleteProductFromDB(productId);
    if (!success) {
      toast({ title: "Error al eliminar producto", description: "No se pudo eliminar el producto.", variant: "destructive" });
      return false;
    }
    setProducts((prevProducts) => prevProducts.filter(p => p.id !== productId));
    toast({ title: "Producto Eliminado", description: "El producto ha sido eliminado del menú." });
    return true;
  };

  const createOrder = async (orderData, itemsData) => {
    const { data: order, error } = await createOrderInDB(orderData, itemsData);
    if (error) {
      toast({ title: "Error al crear pedido", description: error, variant: "destructive" });
      return null;
    }
    if (order) {
      toast({ title: "Pedido Registrado", description: "Tu pedido ha sido registrado exitosamente." });
      clearCart();
      if (isAdminAuthenticated) loadOrders();
      return order;
    }
    return null;
  };

  const addToCart = (product) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find(item => item.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prevCart, { ...product, quantity: 1 }];
    });
    toast({ title: "Añadido al Carrito", description: `${product.name} ha sido añadido a tu carrito.` });
  };

  const removeFromCart = (productId) => {
    setCart((prevCart) => prevCart.filter(item => item.id !== productId));
    toast({ title: "Eliminado del Carrito", description: "Artículo eliminado exitosamente.", variant: "destructive" });
  };

  const updateQuantity = (productId, quantity) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prevCart) =>
      prevCart.map(item =>
        item.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };
  
  const loginAdmin = (username, password) => {
    if (username === 'admin' && password === 'password123') { 
      setIsAdminAuthenticated(true);
      toast({ title: "Inicio de Sesión Exitoso", description: "¡Bienvenido, Admin!" });
      return true;
    }
    toast({ title: "Fallo de Inicio de Sesión", description: "Credenciales inválidas.", variant: "destructive" });
    return false;
  };

  const logoutAdmin = () => {
    setIsAdminAuthenticated(false);
    setOrders([]);
    toast({ title: "Sesión Cerrada", description: "Has cerrado sesión." });
  };

  const getCartTotal = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  const value = {
    products,
    setProducts,
    addProduct,
    updateProduct,
    deleteProduct,
    cart,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    getCartTotal,
    createOrder,
    orders,
    fetchOrders: loadOrders, 
    loadingOrders,
    isAdminAuthenticated,
    loginAdmin,
    logoutAdmin,
    loadingProducts,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};