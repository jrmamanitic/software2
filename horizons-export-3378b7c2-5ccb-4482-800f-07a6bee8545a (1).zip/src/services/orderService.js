import { supabase } from '@/lib/supabaseClient';

export const fetchOrdersFromDB = async () => {
  const { data, error } = await supabase
    .from('orders')
    .select(`
      *,
      order_items (
        *,
        products (name) 
      )
    `)
    .order('created_at', { ascending: false });
  return { data, error };
};

export const createOrderInDB = async (orderData, itemsData) => {
  const { data: order, error: orderError } = await supabase
    .from('orders')
    .insert([orderData])
    .select()
    .single();

  if (orderError) {
    return { data: null, error: orderError.message };
  }

  if (order) {
    const orderItemsWithOrderId = itemsData.map(item => ({
      ...item,
      order_id: order.id,
    }));

    const { error: itemsError } = await supabase
      .from('order_items')
      .insert(orderItemsWithOrderId);

    if (itemsError) {
      await supabase.from('orders').delete().eq('id', order.id);
      return { data: null, error: itemsError.message };
    }
    return { data: order, error: null };
  }
  return { data: null, error: 'Failed to create order.' };
};

export const updateOrderStatusInDB = async (orderId, status, stripeSessionId = null) => {
  const updateData = { status };
  if (stripeSessionId) {
    updateData.stripe_session_id = stripeSessionId;
  }
  const { data, error } = await supabase
    .from('orders')
    .update(updateData)
    .eq('id', orderId)
    .select()
    .single();
  return { data, error };
};

export const getOrderByIdFromDB = async (orderId) => {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .eq('id', orderId)
    .single();
  return { data, error };
};