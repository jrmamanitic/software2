import { supabase } from '@/lib/supabaseClient';

export const fetchProductsFromDB = async () => {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .order('created_at', { ascending: false });
  return { data, error };
};

export const addProductToDB = async (productData) => {
  const { data, error } = await supabase
    .from('products')
    .insert([productData])
    .select()
    .single();
  return { data, error };
};

export const updateProductInDB = async (productId, productData) => {
  const { data, error } = await supabase
    .from('products')
    .update(productData)
    .eq('id', productId)
    .select()
    .single();
  return { data, error };
};

export const deleteProductFromDB = async (productId) => {
  const { error } = await supabase
    .from('products')
    .delete()
    .eq('id', productId);
  return !error;
};